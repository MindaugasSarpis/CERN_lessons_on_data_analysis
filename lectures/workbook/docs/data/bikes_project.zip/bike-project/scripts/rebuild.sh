#!/bin/zsh
grep -v ',9999$' data/raw/bikes.csv > data/processed/bikes_valid.csv
python3 scripts/column_stats.py data/processed/bikes_valid.csv bikes > results/bikes_stats.txt
