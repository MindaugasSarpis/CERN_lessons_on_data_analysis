Select-String ',9999$' data/raw/bikes.csv -NotMatch -Raw > data/processed/bikes_valid.csv
python scripts/column_stats.py data/processed/bikes_valid.csv bikes > results/bikes_stats.txt
