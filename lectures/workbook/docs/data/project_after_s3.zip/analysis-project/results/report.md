# Pendulum

Time of 10 swings for nine lengths.

| length_cm | t10_s |
|--|--|
| 20 | 9.02 |
| 30 | 11.05 |
| 40 | 12.61 |
| 50 | 14.23 |
| 60 | 15.49 |
| 70 | 16.84 |
| 80 | 17.90 |
| 90 | 19.10 |
| 100 | 20.01 |

![Time of 10 swings against length](pendulum_plot.png)
