# Inbox

Files copied from an old laptop. Nobody remembers what is in them.

- Which files are text, and which are not?
- Why does `labas.txt` look broken?
- Are `expenses.csv` and `expenses_copy.csv` the same file?
